How to setup, step by step (currently its in testing so this will definitely change).

1. If you have any antivirus turn it off, as like any other exploit it will trigger your antivirus, and removing everything.
2. After you remove your antivirus open the setup (Celestial) then stuff will appear on the setupstuff folder, (name will change when its released lol).
3. You will need to wait for a while for it to setup and then it should automatically open an executor.
4. Get into any roblox game you want and executor scripts, (the dll is close to KRNL dll power. (prob less))
5. Inject (No keys needed)

(IF THE EXECUTOR DOESNT WORK THEN RUN IT AS ADMINSTRATOR, AND IF THAT DOESNT WORK YOU SHOULD CHECK IF YOUR ANTIVIRUS IS TRIGGERING)